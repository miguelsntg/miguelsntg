package br.unitins.tp1.resource;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.dto.MarcaDTO;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.notNullValue;

@QuarkusTest
public class MarcaResourceTest {

    @Test
    public void testListar() {
        given()
            .when()
                .get("/marcas")
            .then()
                .statusCode(200)
                .body("$", notNullValue())
                .body("nome", hasItem("Logitech"));
    }

    @Test
    public void testBuscarPorId() {
        given()
            .when()
                .get("/marcas/1")
            .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("nome", equalTo("Logitech"))
                .body("paisOrigem", equalTo("Suíça"));
    }

    @Test
    public void testBuscarPorIdInexistente() {
        given()
            .when()
                .get("/marcas/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testBuscarPorNome() {
        given()
            .when()
                .get("/marcas/nome/Logitech")
            .then()
                .statusCode(200)
                .body("nome", hasItem("Logitech"));
    }

    @Test
    public void testInserir() {
        MarcaDTO dto = new MarcaDTO("Razer", "Estados Unidos");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/marcas")
            .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("nome", equalTo("Razer"))
                .body("paisOrigem", equalTo("Estados Unidos"));
    }

    @Test
    public void testInserirValidacaoInvalida() {
        MarcaDTO dtoInvalido = new MarcaDTO("", "Pais Muito Longo Que Ultrapassa Trinta Caracteres Permitidos Pelo DTO");

        given()
            .contentType(ContentType.JSON)
            .body(dtoInvalido)
            .when()
                .post("/marcas")
            .then()
                .statusCode(400);
    }

    @Test
    public void testAtualizar() {
        MarcaDTO dtoInicial = new MarcaDTO("Marca Temporaria", "Brasil");

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dtoInicial)
            .when()
                .post("/marcas")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        MarcaDTO dtoAtualizado = new MarcaDTO("Marca Modificada", "Alemanha");

        given()
            .contentType(ContentType.JSON)
            .body(dtoAtualizado)
            .when()
                .put("/marcas/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/marcas/" + id)
            .then()
                .statusCode(200)
                .body("nome", equalTo("Marca Modificada"))
                .body("paisOrigem", equalTo("Alemanha"));
    }

    @Test
    public void testAtualizarInexistente() {
        MarcaDTO dto = new MarcaDTO("Inexistente", "Brasil");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .put("/marcas/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testExcluir() {
        MarcaDTO dto = new MarcaDTO("Marca Para Excluir", "Japão");

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/marcas")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        given()
            .when()
                .delete("/marcas/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/marcas/" + id)
            .then()
                .statusCode(404);
    }
}

