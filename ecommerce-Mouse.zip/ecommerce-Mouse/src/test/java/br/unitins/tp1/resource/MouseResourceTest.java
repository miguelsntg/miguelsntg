package br.unitins.tp1.resource;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.dto.MouseDTO;
import br.unitins.tp1.model.Switch;
import br.unitins.tp1.model.TipoMouse;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.notNullValue;

@QuarkusTest
public class MouseResourceTest {

    @Test
    public void testListar() {
        given()
            .when()
                .get("/mouses")
            .then()
                .statusCode(200)
                .body("$", notNullValue())
                .body("modelo", hasItem("G203"));
    }

    @Test
    public void testBuscarPorId() {
        given()
            .when()
                .get("/mouses/1")
            .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("modelo", equalTo("G203"));
    }

    @Test
    public void testBuscarPorIdInexistente() {
        given()
            .when()
                .get("/mouses/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testBuscarPorMarca() {
        given()
            .when()
                .get("/mouses/marca/Logitech")
            .then()
                .statusCode(200)
                .body("modelo", hasItem("G203"));
    }

    @Test
    public void testBuscarPorModelo() {
        given()
            .when()
                .get("/mouses/modelo/G203")
            .then()
                .statusCode(200)
                .body("modelo", hasItem("G203"));
    }

    @Test
    public void testInserir() {
        MouseDTO dto = new MouseDTO(
            1L,
            "G Pro X",
            1L,
            1L,
            Switch.OPTICAL,
            null,
            TipoMouse.PADRAO,
            null,
            null,
            null
        );

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/mouses")
            .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("modelo", equalTo("G Pro X"));
    }

    @Test
    public void testInserirValidacaoInvalida() {
        MouseDTO dtoInvalido = new MouseDTO(
            null,
            "",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        );

        given()
            .contentType(ContentType.JSON)
            .body(dtoInvalido)
            .when()
                .post("/mouses")
            .then()
                .statusCode(400);
    }

    @Test
    public void testAtualizar() {
        MouseDTO dtoInicial = new MouseDTO(
            1L,
            "Mouse Temp",
            1L,
            1L,
            Switch.OPTICAL,
            null,
            TipoMouse.PADRAO,
            null,
            null,
            null
        );

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dtoInicial)
            .when()
                .post("/mouses")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        MouseDTO dtoAtualizado = new MouseDTO(
            1L,
            "Mouse Atualizado",
            1L,
            1L,
            Switch.OPTICAL,
            null,
            TipoMouse.PADRAO,
            null,
            null,
            null
        );

        given()
            .contentType(ContentType.JSON)
            .body(dtoAtualizado)
            .when()
                .put("/mouses/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/mouses/" + id)
            .then()
                .statusCode(200)
                .body("modelo", equalTo("Mouse Atualizado"));
    }

    @Test
    public void testAtualizarInexistente() {
        MouseDTO dto = new MouseDTO(
            1L,
            "Inexistente",
            1L,
            1L,
            Switch.OPTICAL,
            null,
            TipoMouse.PADRAO,
            null,
            null,
            null
        );

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .put("/mouses/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testExcluir() {
        MouseDTO dto = new MouseDTO(
            1L,
            "Mouse Excluir",
            1L,
            1L,
            Switch.OPTICAL,
            null,
            TipoMouse.PADRAO,
            null,
            null,
            null
        );

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/mouses")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        given()
            .when()
                .delete("/mouses/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/mouses/" + id)
            .then()
                .statusCode(404);
    }
}

