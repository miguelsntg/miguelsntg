package br.unitins.tp1.resource;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.dto.SensorDTO;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.notNullValue;

@QuarkusTest
public class SensorResourceTest {

    @Test
    public void testListar() {
        given()
            .when()
                .get("/sensores")
            .then()
                .statusCode(200)
                .body("$", notNullValue())
                .body("nome", hasItem("PAW3395"));
    }

    @Test
    public void testBuscarPorId() {
        given()
            .when()
                .get("/sensores/1")
            .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("nome", equalTo("PAW3395"))
                .body("fabricante", equalTo("PixArt"));
    }

    @Test
    public void testBuscarPorIdInexistente() {
        given()
            .when()
                .get("/sensores/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testBuscarPorNome() {
        given()
            .when()
                .get("/sensores/nome/PAW3395")
            .then()
                .statusCode(200)
                .body("nome", hasItem("PAW3395"));
    }

    @Test
    public void testInserir() {
        SensorDTO dto = new SensorDTO("Focus Pro 30K", "Razer");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/sensores")
            .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("nome", equalTo("Focus Pro 30K"))
                .body("fabricante", equalTo("Razer"));
    }

    @Test
    public void testInserirValidacaoInvalida() {
        SensorDTO dtoInvalido = new SensorDTO("", "");

        given()
            .contentType(ContentType.JSON)
            .body(dtoInvalido)
            .when()
                .post("/sensores")
            .then()
                .statusCode(400);
    }

    @Test
    public void testAtualizar() {
        SensorDTO dtoInicial = new SensorDTO("Sensor Temporario", "PixArt");

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dtoInicial)
            .when()
                .post("/sensores")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        SensorDTO dtoAtualizado = new SensorDTO("Sensor Atualizado", "Logitech");

        given()
            .contentType(ContentType.JSON)
            .body(dtoAtualizado)
            .when()
                .put("/sensores/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/sensores/" + id)
            .then()
                .statusCode(200)
                .body("nome", equalTo("Sensor Atualizado"))
                .body("fabricante", equalTo("Logitech"));
    }

    @Test
    public void testAtualizarInexistente() {
        SensorDTO dto = new SensorDTO("Inexistente", "Fabricante");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .put("/sensores/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testExcluir() {
        SensorDTO dto = new SensorDTO("Sensor Para Excluir", "Teste");

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/sensores")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        given()
            .when()
                .delete("/sensores/" + id)
            .then()
                .statusCode(204);

        given()
            .when()
                .get("/sensores/" + id)
            .then()
                .statusCode(404);
    }
}

