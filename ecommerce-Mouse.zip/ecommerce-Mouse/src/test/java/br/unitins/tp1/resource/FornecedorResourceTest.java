package br.unitins.tp1.resource;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.dto.FornecedorDTO;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.notNullValue;

@QuarkusTest
public class FornecedorResourceTest {

    @Test
    public void testListar() {
        given()
            .when()
                .get("/fornecedores")
            .then()
                .statusCode(200)
                .body("$", notNullValue())
                .body("nome", hasItem("Kabum"));
    }

    @Test
    public void testBuscarPorId() {
        given()
            .when()
                .get("/fornecedores/1")
            .then()
                .statusCode(200)
                .body("id", equalTo(1))
                .body("nome", equalTo("Kabum"))
                .body("cnpj", equalTo("12345678901234"))
                .body("email", equalTo("contato@kabum.com"));
    }

    @Test
    public void testBuscarPorIdInexistente() {
        given()
            .when()
                .get("/fornecedores/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testBuscarPorNome() {
        given()
            .when()
                .get("/fornecedores/nome/Kabum")
            .then()
                .statusCode(200)
                .body("nome", hasItem("Kabum"));
    }

    @Test
    public void testInserir() {
        FornecedorDTO dto = new FornecedorDTO(
            "Pichau Gaming",
            "11222333000199",
            "63988887777",
            "contato@pichau.com"
        );

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/fornecedores")
            .then()
                .statusCode(201)
                .body("id", notNullValue())
                .body("nome", equalTo("Pichau Gaming"))
                .body("cnpj", equalTo("11222333000199"))
                .body("telefone", equalTo("63988887777"))
                .body("email", equalTo("contato@pichau.com"));
    }

    @Test
    public void testInserirValidacaoInvalida() {
        // Nome vazio, CNPJ com tamanho incorreto, email inválido
        FornecedorDTO dtoInvalido = new FornecedorDTO(
            "",
            "123",
            "123456789012345678901",
            "email_invalido"
        );

        given()
            .contentType(ContentType.JSON)
            .body(dtoInvalido)
            .when()
                .post("/fornecedores")
            .then()
                .statusCode(400);
    }

    @Test
    public void testAtualizar() {
        // Cria um fornecedor para ser atualizado
        FornecedorDTO dtoInicial = new FornecedorDTO(
            "Fornecedor Para Atualizar",
            "55443322000111",
            "63977776666",
            "inicial@teste.com"
        );

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dtoInicial)
            .when()
                .post("/fornecedores")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        FornecedorDTO dtoAtualizado = new FornecedorDTO(
            "Fornecedor Atualizado",
            "55443322000111",
            "63966665555",
            "atualizado@teste.com"
        );

        given()
            .contentType(ContentType.JSON)
            .body(dtoAtualizado)
            .when()
                .put("/fornecedores/" + id)
            .then()
                .statusCode(204);

        // Verifica se os dados foram realmente atualizados
        given()
            .when()
                .get("/fornecedores/" + id)
            .then()
                .statusCode(200)
                .body("nome", equalTo("Fornecedor Atualizado"))
                .body("email", equalTo("atualizado@teste.com"))
                .body("telefone", equalTo("63966665555"));
    }

    @Test
    public void testAtualizarInexistente() {
        FornecedorDTO dto = new FornecedorDTO(
            "Fornecedor Inexistente",
            "99887766000122",
            "63955554444",
            "inexistente@teste.com"
        );

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .put("/fornecedores/99999")
            .then()
                .statusCode(404);
    }

    @Test
    public void testExcluir() {
        // Cria um fornecedor especificamente para exclusão
        FornecedorDTO dto = new FornecedorDTO(
            "Fornecedor Para Excluir",
            "77889900000133",
            "63944443333",
            "excluir@teste.com"
        );

        Integer id = given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/fornecedores")
            .then()
                .statusCode(201)
                .extract()
                .path("id");

        // Executa a exclusão
        given()
            .when()
                .delete("/fornecedores/" + id)
            .then()
                .statusCode(204);

        // Confirma que não é mais encontrado
        given()
            .when()
                .get("/fornecedores/" + id)
            .then()
                .statusCode(404);
    }
}

