package br.unitins.tp1.resource;

import br.unitins.tp1.dto.MouseDTO;
import br.unitins.tp1.dto.MouseResponseDTO;
import br.unitins.tp1.model.BaseCarregamento;
import br.unitins.tp1.model.Fornecedor;
import br.unitins.tp1.model.Marca;
import br.unitins.tp1.model.Mouse;
import br.unitins.tp1.model.MouseErgonomico;
import br.unitins.tp1.model.MouseGamer;
import br.unitins.tp1.model.MousePadrao;
import br.unitins.tp1.model.Sensor;
import br.unitins.tp1.model.TipoMouse;
import br.unitins.tp1.service.FornecedorService;
import br.unitins.tp1.service.MarcaService;
import br.unitins.tp1.service.MouseService;
import br.unitins.tp1.service.SensorService;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import br.unitins.tp1.exception.ValidationException;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/mouses")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MouseResource {

    @Inject
    MouseService service;
    @Inject
    FornecedorService fornecedorService;
    @Inject
    MarcaService marcaService;
    @Inject
    SensorService sensorService;

    @GET
    public Response listar() {
        return Response.ok(service.findAll().stream()
        .map(MouseResponseDTO::fromEntity)
        .toList()).build();
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") Long id) {
        Mouse mouse = service.findById(id);
        if (mouse == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(MouseResponseDTO.fromEntity(mouse)).build();
    }

    @GET
    @Path("/marca/{marca}")
    public Response buscarPorMarca(@PathParam("marca") String marca) {
        return Response.ok(service.findByMarca(marca).stream().map
        (MouseResponseDTO::fromEntity).toList()).build();
    }

    @GET
    @Path("/modelo/{modelo}")
    public Response buscarPorModelo(@PathParam("modelo") String modelo) {
        return Response.ok(service.findByModelo(modelo).stream().map(MouseResponseDTO::fromEntity).toList()).build();
    }

    @POST
    public Response inserir(@Valid MouseDTO dto) {
        Mouse mouse = toEntity(dto);

        return Response.status(Response.Status.CREATED).entity(MouseResponseDTO.fromEntity(service.create(mouse))).build();
    } 

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") Long id, @Valid MouseDTO dto) {
        Mouse existente = service.findById(id);
        if (existente == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        Mouse mouse = toEntity(dto);
        if (existente.getClass() != mouse.getClass()) {
            throw new ValidationException("tipo", "O tipo do mouse não pode ser alterado após a criação");
        }

        service.update(id, mouse);
        return Response.noContent().build();
    } 

    @DELETE
    @Path("/{id}")
    public Response excluir(@PathParam("id") Long id) {
        service.delete(id);
        return Response.noContent().build();
    }

    private Mouse toEntity(MouseDTO dto) {
        TipoMouse tipo = dto.tipo() == null ? TipoMouse.PADRAO : dto.tipo();
        Mouse mouse = switch (tipo) {
            case PADRAO -> new MousePadrao();
            case GAMER -> {
                if (dto.dpiMaximo() == null || dto.taxaPollingHz() == null) {
                    throw new ValidationException("dpiMaximo", "DPI máximo e taxa de polling são obrigatórios para mouse gamer");
                }
                MouseGamer gamer = new MouseGamer();
                gamer.setDpiMaximo(dto.dpiMaximo());
                gamer.setTaxaPollingHz(dto.taxaPollingHz());
                yield gamer;
            }
            case ERGONOMICO -> {
                if (dto.vertical() == null) {
                    throw new ValidationException("vertical", "Informe se o mouse ergonômico é vertical");
                }
                MouseErgonomico ergonomico = new MouseErgonomico();
                ergonomico.setVertical(dto.vertical());
                yield ergonomico;
            }
        };

        mouse.setModelo(dto.modelo());
        mouse.setTipoSwitch(dto.tipoSwitch());

        Marca marca = marcaService.findById(dto.marcaId());
        if (marca == null) {
            throw new ValidationException("marcaId", "Marca não encontrada");
        }
        mouse.setMarca(marca);

        Fornecedor fornecedor = fornecedorService.findById(dto.fornecedorId());
        if (fornecedor == null) {
            throw new ValidationException("fornecedorId", "Fornecedor não encontrado");
        }
        mouse.setFornecedor(fornecedor);

        Sensor sensor = sensorService.findById(dto.sensorId());
        if (sensor == null) {
            throw new ValidationException("sensorId", "Sensor não encontrado");
        }
        mouse.setSensor(sensor);

        if (dto.baseCarregamento() != null) {
            BaseCarregamento base = new BaseCarregamento();
            base.setModelo(dto.baseCarregamento().modelo());
            base.setPotenciaWatts(dto.baseCarregamento().potenciaWatts());
            base.setTipoConexao(dto.baseCarregamento().tipoConexao());
            mouse.setBaseCarregamento(base);
        }
        return mouse;
    }


}
