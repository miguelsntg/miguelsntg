package br.unitins.tp1.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("ERGONOMICO")
public class MouseErgonomico extends Mouse {

    private Boolean vertical;

    @Override
    public TipoMouse getTipo() {
        return TipoMouse.ERGONOMICO;
    }

    public Boolean getVertical() {
        return vertical;
    }

    public void setVertical(Boolean vertical) {
        this.vertical = vertical;
    }
}