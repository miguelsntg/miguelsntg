package br.unitins.tp1.service;

import java.util.List;

import br.unitins.tp1.exception.EntityNotFoundException;
import br.unitins.tp1.model.Fornecedor;
import br.unitins.tp1.repository.FornecedorRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class FornecedorServiceImpl implements FornecedorService {

    @Inject
    FornecedorRepository repository;

    @Override
    @Transactional
    public Fornecedor create(Fornecedor fornecedor) {
        repository.persist(fornecedor);
        return fornecedor;
    }

    @Override
    @Transactional
    public void update(Long id, Fornecedor fornecedor) {
        Fornecedor fornecedorBanco = repository.findById(id);
        if (fornecedorBanco == null) {
            throw new EntityNotFoundException("Fornecedor não encontrado");
        }
        fornecedorBanco.setNome(fornecedor.getNome());
        fornecedorBanco.setCnpj(fornecedor.getCnpj());
        fornecedorBanco.setTelefone(fornecedor.getTelefone());
        fornecedorBanco.setEmail(fornecedor.getEmail());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Fornecedor findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public List<Fornecedor> findByNome(String nome) {
        return repository.findByNome(nome);
    }

    @Override
    public List<Fornecedor> findAll() {
        return repository.listAll();
    }
}
