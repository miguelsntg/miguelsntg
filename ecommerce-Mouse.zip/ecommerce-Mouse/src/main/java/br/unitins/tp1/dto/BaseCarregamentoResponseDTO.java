package br.unitins.tp1.dto;

import br.unitins.tp1.model.BaseCarregamento;

public record BaseCarregamentoResponseDTO(
    Long id,
    String modelo,
    Integer potenciaWatts,
    String tipoConexao
) {

    public static BaseCarregamentoResponseDTO fromEntity(BaseCarregamento base) {
        if (base == null) {
            return null;
        }
        return new BaseCarregamentoResponseDTO(
            base.getId(),
            base.getModelo(),
            base.getPotenciaWatts(),
            base.getTipoConexao()
        );
    }
}
