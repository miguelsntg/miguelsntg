package br.unitins.tp1.service;

import java.util.List;

import br.unitins.tp1.model.Sensor;

public interface SensorService {
    Sensor create(Sensor sensor);
    void update(Long id, Sensor sensor);
    void delete(Long id);
    Sensor findById(Long id);
    List<Sensor> findByNome(String nome);
    List<Sensor> findAll();
}
