package br.unitins.tp1.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "tipo_mouse", discriminatorType = DiscriminatorType.STRING, length = 20)
public abstract class Mouse extends DefaultEntity {

    private String modelo;

    @ManyToOne
    @JoinColumn(name = "marca_id", nullable = false)
    private Marca marca;

    @ManyToOne
    @JoinColumn(name = "fornecedor_id", nullable = false)
    private Fornecedor fornecedor;

    @ManyToOne
    @JoinColumn(name = "sensor_id", nullable = false)
    private Sensor sensor;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_switch", nullable = false, length = 20)
    private Switch tipoSwitch;

    // Composição: a base de carregamento pertence ao mouse (opcional)
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "base_carregamento_id")
    private BaseCarregamento baseCarregamento;

    // Método abstrato: cada tipo de mouse concreto informa qual é o seu tipo
    public abstract TipoMouse getTipo();

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Marca getMarca() {
        return marca;
    }

    public void setMarca(Marca marca) {
        this.marca = marca;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Sensor getSensor() {
        return sensor;
    }

    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public Switch getTipoSwitch() {
        return tipoSwitch;
    }

    public void setTipoSwitch(Switch tipoSwitch) {
        this.tipoSwitch = tipoSwitch;
    }

    public BaseCarregamento getBaseCarregamento() {
        return baseCarregamento;
    }

    public void setBaseCarregamento(BaseCarregamento baseCarregamento) {
        this.baseCarregamento = baseCarregamento;
    }
}
