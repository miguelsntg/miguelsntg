package br.unitins.tp1.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record FornecedorDTO(
        @NotBlank(message = "O nome do fornecedor deve ser informado")
        @Size(max = 50, message = "O nome deve conter no máximo 50 caracteres")
        String nome,
        @NotBlank(message = "O CNPJ deve ser informado")
        @Size(min = 14, max = 14, message = "O CNPJ deve conter 14 dígitos")
        String cnpj,
        @Size(max = 20, message = "O telefone deve conter no máximo 20 caracteres")
        String telefone,
        @Email(message = "E-mail inválido")
        String email
    ) {
}
