package br.unitins.tp1.model;

public enum Switch {
    OPTICAL,
    MAGNETICO
}
