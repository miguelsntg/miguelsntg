package br.unitins.tp1.resource;

import br.unitins.tp1.dto.SensorDTO;
import br.unitins.tp1.dto.SensorResponseDTO;
import br.unitins.tp1.model.Sensor;
import br.unitins.tp1.service.SensorService;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/sensores")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SensorResource {

    @Inject
    SensorService service;

    @GET
    public Response listar() {
        return Response.ok(service.findAll().stream()
                .map(SensorResponseDTO::fromEntity)
                .toList()).build();
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") Long id) {
        Sensor sensor = service.findById(id);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(SensorResponseDTO.fromEntity(sensor)).build();
    }

    @GET
    @Path("/nome/{nome}")
    public Response buscarPorNome(@PathParam("nome") String nome) {
        return Response.ok(service.findByNome(nome).stream()
                .map(SensorResponseDTO::fromEntity)
                .toList()).build();
    }

    @POST
    public Response inserir(@Valid SensorDTO dto) {
        Sensor sensor = toEntity(dto);
        return Response.status(Response.Status.CREATED)
                .entity(SensorResponseDTO.fromEntity(service.create(sensor))).build();
    }

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") Long id, @Valid SensorDTO dto) {
        if (service.findById(id) == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        service.update(id, toEntity(dto));
        return Response.noContent().build();
    }

    @DELETE
    @Path("/{id}")
    public Response excluir(@PathParam("id") Long id) {
        service.delete(id);
        return Response.noContent().build();
    }

    private Sensor toEntity(SensorDTO dto) {
        Sensor sensor = new Sensor();
        sensor.setNome(dto.nome());
        sensor.setFabricante(dto.fabricante());
        return sensor;
    }
}
