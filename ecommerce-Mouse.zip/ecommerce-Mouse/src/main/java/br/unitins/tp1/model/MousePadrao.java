package br.unitins.tp1.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("PADRAO")
public class MousePadrao extends Mouse {

    @Override
    public TipoMouse getTipo() {
        return TipoMouse.PADRAO;
    }
}
