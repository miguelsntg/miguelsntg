package br.unitins.tp1.service;

import java.util.List;

import br.unitins.tp1.exception.EntityNotFoundException;
import br.unitins.tp1.model.Sensor;
import br.unitins.tp1.repository.SensorRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class SensorServiceImpl implements SensorService {

    @Inject
    SensorRepository repository;

    @Override
    @Transactional
    public Sensor create(Sensor sensor) {
        repository.persist(sensor);
        return sensor;
    }

    @Override
    @Transactional
    public void update(Long id, Sensor sensor) {
        Sensor sensorBanco = repository.findById(id);
        if (sensorBanco == null) {
            throw new EntityNotFoundException("Sensor não encontrado");
        }
        sensorBanco.setNome(sensor.getNome());
        sensorBanco.setFabricante(sensor.getFabricante());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Sensor findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public List<Sensor> findByNome(String nome) {
        return repository.findByNome(nome);
    }

    @Override
    public List<Sensor> findAll() {
        return repository.listAll();
    }
}
