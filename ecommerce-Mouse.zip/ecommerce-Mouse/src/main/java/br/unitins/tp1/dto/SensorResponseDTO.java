package br.unitins.tp1.dto;

import br.unitins.tp1.model.Sensor;

public record SensorResponseDTO(
    Long id,
    String nome,
    String fabricante
) {

    public static SensorResponseDTO fromEntity(Sensor sensor) {
        return new SensorResponseDTO(sensor.getId(), sensor.getNome(), sensor.getFabricante());
    }
}
