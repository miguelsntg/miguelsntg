package br.unitins.tp1.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record SensorDTO(
        @NotBlank(message = "O nome do sensor deve ser informado")
        @Size(max = 30, message = "O nome do sensor deve conter no máximo 30 caracteres")
        String nome,
        @NotBlank(message = "O fabricante do sensor deve ser informado")
        @Size(max = 30, message = "O fabricante deve conter no máximo 30 caracteres")
        String fabricante
    ) {
}
