package br.unitins.tp1.service;

import java.util.List;

import br.unitins.tp1.exception.EntityNotFoundException;
import br.unitins.tp1.model.BaseCarregamento;
import br.unitins.tp1.model.Mouse;
import br.unitins.tp1.model.MouseErgonomico;
import br.unitins.tp1.model.MouseGamer;
import br.unitins.tp1.repository.MouseRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class MouseServiceImpl implements MouseService {

    @Inject
    MouseRepository repository;

    @Override
    @Transactional
    public Mouse create(Mouse mouse) {
        repository.persist(mouse);
        return mouse;
    }

    @Override
    @Transactional
    public void update(Long id, Mouse mouse) {
        Mouse mouseBanco = repository.findById(id);
        if (mouseBanco == null) {
            throw new EntityNotFoundException("Mouse não encontrado");
        }
        mouseBanco.setMarca(mouse.getMarca());
        mouseBanco.setModelo(mouse.getModelo());
        mouseBanco.setFornecedor(mouse.getFornecedor());
        mouseBanco.setSensor(mouse.getSensor());
        mouseBanco.setTipoSwitch(mouse.getTipoSwitch());
        atualizarBaseCarregamento(mouseBanco, mouse.getBaseCarregamento());

        if (mouseBanco instanceof MouseGamer gamerBanco && mouse instanceof MouseGamer gamer) {
            gamerBanco.setDpiMaximo(gamer.getDpiMaximo());
            gamerBanco.setTaxaPollingHz(gamer.getTaxaPollingHz());
        } else if (mouseBanco instanceof MouseErgonomico ergonomicoBanco
                && mouse instanceof MouseErgonomico ergonomico) {
            ergonomicoBanco.setVertical(ergonomico.getVertical());
        }
    }

    // Composição: remover a base do DTO apaga a base do banco (orphanRemoval)
    private void atualizarBaseCarregamento(Mouse banco, BaseCarregamento nova) {
        if (nova == null) {
            banco.setBaseCarregamento(null);
            return;
        }
        BaseCarregamento atual = banco.getBaseCarregamento();
        if (atual == null) {
            banco.setBaseCarregamento(nova);
            return;
        }
        atual.setModelo(nova.getModelo());
        atual.setPotenciaWatts(nova.getPotenciaWatts());
        atual.setTipoConexao(nova.getTipoConexao());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Mouse findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public List<Mouse> findByMarca(String marca) {
        return repository.findByMarca(marca);
    }

    @Override
    public List<Mouse> findByModelo(String modelo) {
        return repository.findByModelo(modelo);
    }

    @Override
    public List<Mouse> findAll() {
        return repository.listAll();
    }

}
