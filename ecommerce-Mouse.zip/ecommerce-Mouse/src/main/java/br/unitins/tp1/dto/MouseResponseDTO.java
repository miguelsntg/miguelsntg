package br.unitins.tp1.dto;

import br.unitins.tp1.model.Mouse;
import br.unitins.tp1.model.MouseErgonomico;
import br.unitins.tp1.model.MouseGamer;
import br.unitins.tp1.model.Switch;
import br.unitins.tp1.model.TipoMouse;

public record MouseResponseDTO(
    Long id,
    Long marcaId,
    String marca,
    String modelo,
    Long fornecedorId,
    Long sensorId,
    String sensor,
    Switch tipoSwitch,
    BaseCarregamentoResponseDTO baseCarregamento,
    TipoMouse tipo,
    Integer dpiMaximo,
    Integer taxaPollingHz,
    Boolean vertical
) {

    public static MouseResponseDTO fromEntity(Mouse mouse) {
        TipoMouse tipo = mouse.getTipo();
        Integer dpiMaximo = null;
        Integer taxaPollingHz = null;
        Boolean vertical = null;

        if (mouse instanceof MouseGamer gamer) {
            dpiMaximo = gamer.getDpiMaximo();
            taxaPollingHz = gamer.getTaxaPollingHz();
        } else if (mouse instanceof MouseErgonomico ergonomico) {
            vertical = ergonomico.getVertical();
        }

        return new MouseResponseDTO(
            mouse.getId(),
            mouse.getMarca().getId(),
            mouse.getMarca().getNome(),
            mouse.getModelo(),
            mouse.getFornecedor().getId(),
            mouse.getSensor().getId(),
            mouse.getSensor().getNome(),
            mouse.getTipoSwitch(),
            BaseCarregamentoResponseDTO.fromEntity(mouse.getBaseCarregamento()),
            tipo,
            dpiMaximo,
            taxaPollingHz,
            vertical
        );
    }
}
