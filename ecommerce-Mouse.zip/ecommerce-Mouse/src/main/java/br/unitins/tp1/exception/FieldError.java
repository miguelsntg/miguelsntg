package br.unitins.tp1.exception;

public record FieldError(
    String campo,
    String mensagem
) {
}

