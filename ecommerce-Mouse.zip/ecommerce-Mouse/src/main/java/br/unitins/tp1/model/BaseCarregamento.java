package br.unitins.tp1.model;

import jakarta.persistence.Entity;

@Entity
public class BaseCarregamento extends DefaultEntity {

    private String modelo;
    private Integer potenciaWatts;
    private String tipoConexao;

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Integer getPotenciaWatts() {
        return potenciaWatts;
    }

    public void setPotenciaWatts(Integer potenciaWatts) {
        this.potenciaWatts = potenciaWatts;
    }

    public String getTipoConexao() {
        return tipoConexao;
    }

    public void setTipoConexao(String tipoConexao) {
        this.tipoConexao = tipoConexao;
    }
}
