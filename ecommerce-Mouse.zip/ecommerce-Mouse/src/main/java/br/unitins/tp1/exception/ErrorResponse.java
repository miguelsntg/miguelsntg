package br.unitins.tp1.exception;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(
    String codigo,
    String mensagem,
    String campo,
    List<FieldError> erros
) {
    public ErrorResponse(String codigo, String mensagem) {
        this(codigo, mensagem, null, null);
    }

    public ErrorResponse(String codigo, String campo, String mensagem) {
        this(codigo, mensagem, campo, null);
    }

    public ErrorResponse(String codigo, String mensagem, List<FieldError> erros) {
        this(codigo, mensagem, null, erros);
    }
}

