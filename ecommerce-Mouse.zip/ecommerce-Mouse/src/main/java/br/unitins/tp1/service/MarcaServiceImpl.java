package br.unitins.tp1.service;

import java.util.List;

import br.unitins.tp1.exception.EntityNotFoundException;
import br.unitins.tp1.model.Marca;
import br.unitins.tp1.repository.MarcaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class MarcaServiceImpl implements MarcaService {

    @Inject
    MarcaRepository repository;

    @Override
    @Transactional
    public Marca create(Marca marca) {
        repository.persist(marca);
        return marca;
    }

    @Override
    @Transactional
    public void update(Long id, Marca marca) {
        Marca marcaBanco = repository.findById(id);
        if (marcaBanco == null) {
            throw new EntityNotFoundException("Marca não encontrada");
        }
        marcaBanco.setNome(marca.getNome());
        marcaBanco.setPaisOrigem(marca.getPaisOrigem());
    }

    @Override
    @Transactional
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Marca findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public List<Marca> findByNome(String nome) {
        return repository.findByNome(nome);
    }

    @Override
    public List<Marca> findAll() {
        return repository.listAll();
    }
}
