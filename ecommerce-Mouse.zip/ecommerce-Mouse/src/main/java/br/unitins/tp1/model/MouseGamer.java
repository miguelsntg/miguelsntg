package br.unitins.tp1.model;

import jakarta.persistence.Entity;
import jakarta.persistence.DiscriminatorValue;

@Entity
@DiscriminatorValue("GAMER")
public class MouseGamer extends Mouse {

    private Integer dpiMaximo;
    private Integer taxaPollingHz;

    @Override
    public TipoMouse getTipo() {
        return TipoMouse.GAMER;
    }

    public Integer getDpiMaximo() {
        return dpiMaximo;
    }

    public void setDpiMaximo(Integer dpiMaximo) {
        this.dpiMaximo = dpiMaximo;
    }

    public Integer getTaxaPollingHz() {
        return taxaPollingHz;
    }

    public void setTaxaPollingHz(Integer taxaPollingHz) {
        this.taxaPollingHz = taxaPollingHz;
    }
}