package br.unitins.tp1.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record BaseCarregamentoDTO(
        @NotBlank(message = "O modelo da base deve ser informado")
        @Size(max = 30, message = "O modelo da base deve conter no máximo 30 caracteres")
        String modelo,
        @NotNull(message = "A potência da base deve ser informada")
        @Positive(message = "A potência deve ser positiva")
        Integer potenciaWatts,
        @Size(max = 20, message = "O tipo de conexão deve conter no máximo 20 caracteres")
        String tipoConexao
    ) {
}
