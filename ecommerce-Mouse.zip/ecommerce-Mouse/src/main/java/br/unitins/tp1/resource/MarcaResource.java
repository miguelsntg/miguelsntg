package br.unitins.tp1.resource;

import br.unitins.tp1.dto.MarcaDTO;
import br.unitins.tp1.dto.MarcaResponseDTO;
import br.unitins.tp1.model.Marca;
import br.unitins.tp1.service.MarcaService;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/marcas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MarcaResource {

    @Inject
    MarcaService service;

    @GET
    public Response listar() {
        return Response.ok(service.findAll().stream()
                .map(MarcaResponseDTO::fromEntity)
                .toList()).build();
    }

    @GET
    @Path("/{id}")
    public Response buscarPorId(@PathParam("id") Long id) {
        Marca marca = service.findById(id);
        if (marca == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(MarcaResponseDTO.fromEntity(marca)).build();
    }

    @GET
    @Path("/nome/{nome}")
    public Response buscarPorNome(@PathParam("nome") String nome) {
        return Response.ok(service.findByNome(nome).stream()
                .map(MarcaResponseDTO::fromEntity)
                .toList()).build();
    }

    @POST
    public Response inserir(@Valid MarcaDTO dto) {
        Marca marca = toEntity(dto);
        return Response.status(Response.Status.CREATED)
                .entity(MarcaResponseDTO.fromEntity(service.create(marca))).build();
    }

    @PUT
    @Path("/{id}")
    public Response atualizar(@PathParam("id") Long id, @Valid MarcaDTO dto) {
        if (service.findById(id) == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        service.update(id, toEntity(dto));
        return Response.noContent().build();
    }

    @DELETE
    @Path("/{id}")
    public Response excluir(@PathParam("id") Long id) {
        service.delete(id);
        return Response.noContent().build();
    }

    private Marca toEntity(MarcaDTO dto) {
        Marca marca = new Marca();
        marca.setNome(dto.nome());
        marca.setPaisOrigem(dto.paisOrigem());
        return marca;
    }
}
