package br.unitins.tp1.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record MarcaDTO(
        @NotBlank(message = "O nome da marca deve ser informado")
        @Size(max = 30, message = "O nome da marca deve conter no máximo 30 caracteres")
        String nome,
        @Size(max = 30, message = "O país de origem deve conter no máximo 30 caracteres")
        String paisOrigem
    ) {
}
