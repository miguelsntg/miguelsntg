package br.unitins.tp1.model;

public enum TipoMouse {
    PADRAO,
    GAMER,
    ERGONOMICO
}