package br.unitins.tp1.dto;

import br.unitins.tp1.model.Switch;
import br.unitins.tp1.model.TipoMouse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public record MouseDTO(
        @NotNull(message = "A marca deve ser informada")
        Long marcaId,
        @NotBlank(message = "O modelo deve ser informado")
        @Size(max = 20, message = "O modelo deve conter no máximo 20 caracteres")
        String modelo,
        @NotNull(message = "O fornecedor deve ser informado")
        Long fornecedorId,
        @NotNull(message = "O sensor deve ser informado")
        Long sensorId,
        @NotNull(message = "O tipo de switch deve ser informado")
        Switch tipoSwitch,
        @Valid
        BaseCarregamentoDTO baseCarregamento,
        TipoMouse tipo,
        @Positive(message = "O DPI máximo deve ser positivo")
        Integer dpiMaximo,
        @Positive(message = "A taxa de polling deve ser positiva")
        Integer taxaPollingHz,
        Boolean vertical
    ) {
}
