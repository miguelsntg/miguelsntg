-- Dados iniciais (dev/test)
insert into fornecedor (nome, cnpj, telefone, email) values('Kabum', '12345678901234', '123456789', 'contato@kabum.com');
insert into fornecedor (nome, cnpj, telefone, email) values('Terabyte', '98765432109876', '987654321', 'contato@terabyte.com');

insert into marca (nome, paisOrigem) values('Logitech', 'Suíça');
insert into marca (nome, paisOrigem) values('Pulsar', 'Estados Unidos');
insert into marca (nome, paisOrigem) values('Redragon', 'China');
insert into marca (nome, paisOrigem) values('MotoSpeed', 'China');

insert into sensor (nome, fabricante) values('PAW3395', 'PixArt');
insert into sensor (nome, fabricante) values('PAW3325', 'PixArt');
insert into sensor (nome, fabricante) values('HERO 25K', 'Logitech');

insert into mouse (marca_id, modelo, fornecedor_id, sensor_id, tipo_switch, tipo_mouse) values(1, 'G203', 1, 3, 'OPTICAL', 'PADRAO');
insert into mouse (marca_id, modelo, fornecedor_id, sensor_id, tipo_switch, tipo_mouse) values(2, 'PS-100', 2, 1, 'MAGNETICO', 'PADRAO');
insert into mouse (marca_id, modelo, fornecedor_id, sensor_id, tipo_switch, tipo_mouse) values(3, 'M650', 1, 2, 'OPTICAL', 'PADRAO');
insert into mouse (marca_id, modelo, fornecedor_id, sensor_id, tipo_switch, tipo_mouse) values(4, 'X6', 2, 2, 'OPTICAL', 'PADRAO');

-- Mouse é abstrato: os mouses padrão ficam na tabela da subclasse MousePadrao
insert into MousePadrao (id) select id from Mouse where tipo_mouse = 'PADRAO';
